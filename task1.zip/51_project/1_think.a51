        ORG 0000H
;--------------------------------
; 第一步：将 01H~21H 写入片内 RAM 35H~55H
;--------------------------------
        MOV R0,#35H        ; R0 指向片内 RAM 起始地址 35H
        MOV A,#01H         ; 初始数据 01H
        MOV R7,#21H        ; 共 33 个数据

WRITE:  MOV @R0,A          ; 写入片内 RAM
        INC A              ; 数据加 1
        INC R0             ; RAM 地址加 1
        DJNZ R7,WRITE      ; 循环 33 次

;--------------------------------
; 第二步：将片内 RAM 35H~55H 复制到外部 RAM 3000H 开始
;--------------------------------
        MOV R0,#35H        ; 重新指向片内 RAM 35H
        MOV DPTR,#3000H    ; 外部 RAM 起始地址 3000H
        MOV R7,#21H        ; 共复制 33 个数据

COPY:   MOV A,@R0          ; 取片内 RAM 数据
        MOVX @DPTR,A       ; 写入外部 RAM
        INC R0             ; 片内 RAM 地址加 1
        INC DPTR           ; 外部 RAM 地址加 1
        DJNZ R7,COPY       ; 循环 33 次

HERE:   SJMP HERE          ; 程序结束，停在这里

        END