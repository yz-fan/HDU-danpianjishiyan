ORG 0000H        ; 程序从0000H开始
LJMP MAIN        ; 跳转到主程序

ORG 0030H        ; 主程序存放地址
MAIN:
    MOV R0, #35H  ; 起始地址：35H → R0（间接寻址寄存器）
    MOV R2, #21H  ; 字节数：55H - 35H + 1 = 21H（33个字节）
    MOV A, #0FFH  ; 要写入的数据 → A

LOOP:
    MOV @R0, A    ; 将A中的0FFH写入R0指向的RAM单元
    INC R0        ; 地址+1，指向下一个单元
    DJNZ R2, LOOP ; 循环直到所有单元写完

SJMP $          ; 程序原地停机（结束）
END             ; 汇编结束