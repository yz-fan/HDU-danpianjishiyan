        ORG 0000H

        MOV R0,#35H        ; R0 指向片内 RAM 起始地址 35H
        MOV DPTR,#3000H    ; DPTR 指向外部 RAM 起始地址 3000H
        MOV R7,#21H        ; 共传送 33 个字节，33D = 21H

LOOP:   MOV A,@R0          ; 从片内 RAM 取数据
        MOVX @DPTR,A       ; 写入外部 RAM，地址为 DPTR
        INC R0             ; 片内 RAM 地址加 1
        INC DPTR           ; 外部 RAM 地址加 1
        DJNZ R7,LOOP       ; 传送未完成则继续

HERE:   SJMP HERE

        END