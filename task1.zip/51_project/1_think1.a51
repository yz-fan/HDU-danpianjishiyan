        ORG 0000H
        LJMP MAIN

        ORG 0030H

MAIN:
        MOV R0,#35H          ; R0 指向片内 RAM 起始地址 35H
        MOV DPTR,#3000H      ; DPTR 指向外部 RAM 起始地址 3000H
        MOV R2,#21H          ; 共传送 21H 个字节，即 33 个字节

LOOP:
        MOV A,@R0            ; 从片内 RAM 取出 R0 指向单元的数据
        MOVX @DPTR,A         ; 把 A 中的数据写入 DPTR 指向的外部 RAM
        INC R0               ; 片内 RAM 地址加 1
        INC DPTR             ; 外部 RAM 地址加 1
        DJNZ R2,LOOP         ; R2 减 1，不为 0 则继续循环

        SJMP $               ; 程序结束后原地等待

        END                  ; 汇编结束