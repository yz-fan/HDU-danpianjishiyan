#include <reg51.h>  //中断方式

sbit WAVE = P1^0;  // 定义输出引脚


void Timer0_ISR(void) interrupt 1 {
    TH0 = 0xAA;    // 重装初值高8位
    TL0 = 0x10;    // 重装初值低8位
    WAVE = ~WAVE;  // 电平翻转
}

void main(void) {
    TMOD = 0x01;   // T0工作方式1
    TH0  = 0xAA;   // 装载初值
    TL0  = 0x10;
    EA   = 1;      // 开总中断
    ET0  = 1;      // 开T0中断
    TR0  = 1;      // 启动T0
    
    while(1);      // 主循环等待中断
}