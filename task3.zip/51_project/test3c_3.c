#include <reg51.h>

sbit WAVE = P2^0;     // 方波输出端口

unsigned char mode = 0;       // 0:1kHz, 1:100Hz, 2:10Hz, 3:1Hz
unsigned int cnt = 0;         // 定时器中断计数
unsigned int debounce = 0;    // 按键消抖计数

unsigned int code half_period_count[4] = {
    1,      // 1kHz，半周期 500us
    10,     // 100Hz，半周期 5ms
    100,    // 10Hz，半周期 50ms
    1000    // 1Hz，半周期 500ms
};

void Timer0_Init(void)
{
    TMOD &= 0xF0;      // 清除 T0 控制位
    TMOD |= 0x02;      // T0 工作方式 2，8 位自动重装

    TH0 = 0x06;        // 500us 定时
    TL0 = 0x06;

    ET0 = 1;           // 允许 T0 中断
    TR0 = 1;           // 启动 T0
}

void INT0_Init(void)
{
    IT0 = 1;           // INT0 下降沿触发
    EX0 = 1;           // 允许 INT0 中断
}

void Timer0_ISR(void) interrupt 1
{
    if (debounce > 0)
    {
        debounce--;
    }

    cnt++;

    if (cnt >= half_period_count[mode])
    {
        cnt = 0;
        WAVE = ~WAVE;  // 翻转输出，形成方波
    }
}

void INT0_ISR(void) interrupt 0
{
    if (debounce == 0)
    {
        mode++;

        if (mode >= 4)
        {
            mode = 0;
        }

        cnt = 0;           // 切换频率后重新计数
        WAVE = 0;          // 从低电平重新开始输出

        debounce = 40;     // 40 × 500us = 20ms 消抖
    }
}

void main(void)
{
    WAVE = 0;

    Timer0_Init();
    INT0_Init();

    EA = 1;              // 开总中断

    while (1)
    {
        // 主循环无需处理
    }
}