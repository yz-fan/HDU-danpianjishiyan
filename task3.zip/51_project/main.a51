        ORG 0000H          ;中断方式
        LJMP MAIN
        ORG 000BH          ; T0中断向量地址
        LJMP T0_ISR
        
        ORG 0030H
MAIN:   MOV TMOD, #01H     ; T0方式1
        MOV TH0, #0AAH     ; 装初值高8位
        MOV TL0, #010H     ; 装初值低8位
        SETB EA            ; 开总中断
        SETB ET0           ; 开T0中断
        SETB TR0           ; 启动T0
LOOP:   SJMP LOOP          ; 等待中断

T0_ISR: MOV TH0, #0AAH     ; 重装初值
        MOV TL0, #010H
        CPL P1.0           ; P1.0取反
        RETI               ; 中断返回
        
        END
