#include <reg51.h>        // 包含51单片机寄存器定义头文件

sbit WAVE = P2^0;         // 定义方波信号输出引脚为P2.0

#define MAX_SLICE_US 50000UL    // 定义最大定时切片长度50000微秒
#define KEY_GUARD_MS 50         // 定义按键消抖时间50毫秒

unsigned char freq_mode = 0;    // 频率模式变量：0=1kHz,1=100Hz,2=10Hz,3=1Hz
unsigned char duty = 50;        // 占空比变量，初始值设为50%

bit wave_level = 0;             // 记录当前输出的电平状态（0低1高）
unsigned long phase_remain_us;  // 记录当前相位剩余的定时时间（微秒）

volatile unsigned int ms_tick;  // 系统毫秒计时基准（不断自增）
unsigned int last_k1_ms = 0;    // 记录K1按键上次触发的时间
unsigned int last_k2_ms = 0;    // 记录K2按键上次触发的时间

// 定义4种频率对应的周期值（微秒）
unsigned long code period_us[4] = {
    1000UL,       // 下标0：1kHz，周期1ms
    10000UL,      // 下标1：100Hz，周期10ms
    100000UL,     // 下标2：10Hz，周期100ms
    1000000UL     // 下标3：1Hz，周期1000ms
};

// 函数功能：根据指定微秒数装载定时器0初值
void Timer0_Load_us(unsigned int t_us)
{
    unsigned int count;         // 定义计数次数变量
    unsigned int reload_value;  // 定义定时器重装值变量

    count = t_us / 2;   // 6MHz晶振，机器周期2us，计算需要计数的次数

    reload_value = (unsigned int)(65536UL - count);  // 计算定时器初值

    TR0 = 0;            // 关闭定时器0，防止装载时中断触发

    TH0 = (unsigned char)(reload_value >> 8);    // 装载初值高8位
    TL0 = (unsigned char)(reload_value & 0xFF);  // 装载初值低8位

    TF0 = 0;            // 清除定时器0溢出标志
    TR0 = 1;            // 重新启动定时器0
}

// 函数功能：安排下一段定时任务，分段处理超长延时
void Timer0_ScheduleNext(void)
{
    unsigned int slice_us;  // 定义本次定时切片长度

    // 如果剩余时间大于最大切片，只定时最大长度
    if (phase_remain_us > MAX_SLICE_US)
    {
        slice_us = (unsigned int)MAX_SLICE_US;
        phase_remain_us -= MAX_SLICE_US;  // 减去已定时部分
    }
    // 剩余时间不足，定时剩余全部时间
    else
    {
        slice_us = (unsigned int)phase_remain_us;
        phase_remain_us = 0;  // 剩余时间清零
    }

    Timer0_Load_us(slice_us);  // 装载定时并启动
}

// 函数功能：开始输出一个新的电平相位
void Wave_StartPhase(bit level)
{
    unsigned long period;         // 存储当前周期
    unsigned long high_time;       // 存储高电平时间
    unsigned long this_phase_time; // 存储当前相位持续时间

    wave_level = level;    // 更新当前电平状态
    WAVE = level;          // 输出引脚设置为对应电平

    period = period_us[freq_mode];  // 获取当前频率的总周期

    high_time = period * duty / 100;  // 计算高电平持续时间

    // 如果当前是高电平相位
    if (level == 1)
    {
        this_phase_time = high_time;
    }
    // 如果当前是低电平相位
    else
    {
        this_phase_time = period - high_time;
    }

    phase_remain_us = this_phase_time;  // 设置剩余时间

    Timer0_ScheduleNext();  // 启动定时
}

// 函数功能：重启波形输出（切换频率/占空比时调用）
void Wave_Restart(void)
{
    TR0 = 0;    // 关闭定时器0
    TF0 = 0;    // 清除溢出标志

    Wave_StartPhase(1);  // 从高电平重新开始输出波形
}

// 定时器0中断服务函数：波形生成核心
void Timer0_ISR(void) interrupt 1
{
    // 如果当前相位还未结束，继续定时
    if (phase_remain_us > 0)
    {
        Timer0_ScheduleNext();
    }
    // 当前相位结束，翻转电平开始下一相位
    else
    {
        Wave_StartPhase(!wave_level);
    }
}

// 函数功能：装载定时器1初值，实现1ms定时
void Timer1_Load_1ms(void)
{
    /*
        6MHz 晶振，12T模式：
        机器周期 = 2us
        1ms需要500个机器周期
        初值 = 65536 - 500 = 65036 = 0xFE0C
    */
    TH1 = 0xFE;    // 高8位初值
    TL1 = 0x0C;    // 低8位初值
}

// 定时器1中断服务函数：提供系统毫秒时钟
void Timer1_ISR(void) interrupt 3
{
    Timer1_Load_1ms();  // 重装初值
    ms_tick++;          // 毫秒计数器自增
}

// INT0中断服务函数：K1按键，切换频率模式
void INT0_ISR(void) interrupt 0
{
    unsigned int now;    // 存储当前时间

    now = ms_tick;      // 获取当前毫秒时间

    // 与上次按键间隔大于消抖时间，判定为有效按键
    if ((unsigned int)(now - last_k1_ms) >= KEY_GUARD_MS)
    {
        last_k1_ms = now;       // 更新按键时间

        freq_mode++;            // 频率模式+1

        if (freq_mode >= 4)     // 超过3则回到0
        {
            freq_mode = 0;
        }

        Wave_Restart();         // 重启波形输出
    }
}

// INT1中断服务函数：K2按键，调整占空比
void INT1_ISR(void) interrupt 2
{
    unsigned int now;    // 存储当前时间

    now = ms_tick;      // 获取当前毫秒时间

    // 消抖判断
    if ((unsigned int)(now - last_k2_ms) >= KEY_GUARD_MS)
    {
        last_k2_ms = now;       // 更新按键时间

        duty += 10;             // 占空比+10%

        if (duty > 90)          // 超过90%则回到10%
        {
            duty = 10;
        }

        Wave_Restart();         // 重启波形输出
    }
}

// 系统初始化函数
void Init_System(void)
{
    /*
        TMOD模式设置：
        T1 工作方式1（16位定时器）
        T0 工作方式1（16位定时器）
    */
    TMOD = 0x11;

    Timer1_Load_1ms();  // 初始化T1为1ms定时

    ET0 = 1;     // 使能定时器0中断
    ET1 = 1;     // 使能定时器1中断

    IT0 = 1;     // 设置INT0为下降沿触发
    IT1 = 1;     // 设置INT1为下降沿触发

    EX0 = 1;     // 使能外部中断0
    EX1 = 1;     // 使能外部中断1

    TR1 = 1;     // 启动定时器1

    Wave_Restart();  // 启动波形输出

    EA = 1;      // 开启总中断
}

// 主函数
void main(void)
{
    WAVE = 0;    // 初始输出低电平

    Init_System();  // 调用系统初始化

    while (1)       // 死循环，所有功能由中断完成
    {
        // 主循环空闲，无需执行任务
    }
}