#include <reg51.h>

// 定义P2.0引脚
sbit P2_0 = P2^0;

// 定义常量
#define N_HIGH 85    // 高电平期间的溢出次数
#define N_LOW  165   // 低电平期间的溢出次数
#define HIGH   1     // 高电平状态
#define LOW    0     // 低电平状态

// 全局变量（volatile确保ISR正确访问）
volatile unsigned char counter;
volatile unsigned char state;

// T1中断服务程序（中断号3）
void timer1_isr(void) interrupt 3 {
    counter--;  // 递减计数器
    if (counter == 0) {
        if (state == HIGH) {
            P2_0 = 0;       // 切换为低电平
            state = LOW;    // 更新状态
            counter = N_LOW; // 重置计数器
        } else {
            P2_0 = 1;       // 切换为高电平
            state = HIGH;   // 更新状态
            counter = N_HIGH; // 重置计数器
        }
    }
}

void main() {
    // 初始化P2.0为高电平
    P2_0 = 1;
    
    // 配置T1为方式2（8位自动重装）
    TMOD = 0x20;  // T1模式2, T0模式0
    TH1  = 0x10;  // 重装初值16 (0x10)
    TL1  = 0x10;  // 初始计数值16 (0x10)
    
    // 初始化状态变量
    counter = N_HIGH; // 从高电平开始
    state   = HIGH;
    
    // 使能中断
    ET1 = 1;  // 使能T1中断
    EA  = 1;  // 使能全局中断
    
    // 启动T1
    TR1 = 1;  // 启动定时器
    
    // 主循环（空闲）
    while (1) {
        // 所有操作在中断中处理，主循环无需操作
    }
}