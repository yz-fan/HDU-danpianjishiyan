        ORG 0000H          ;查询方式
        LJMP MAIN
        
        ORG 0030H
MAIN:   MOV TMOD, #01H     ; T0方式1
        MOV TH0, #0AAH     ; 装初值
        MOV TL0, #010H
        SETB TR0           ; 启动T0

LOOP:   JNB TF0, LOOP      ; 查询TF0，未溢出则继续查询
        CLR TF0            ; 溢出，手动清0标志位
        MOV TH0, #0AAH     ; 重装初值
        MOV TL0, #010H
        CPL P1.0           ; P1.0取反
        SJMP LOOP          ; 继续循环查询
        
        END