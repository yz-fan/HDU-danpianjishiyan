#include <reg51.h>   //查询方式

sbit WAVE = P1^0;

void main(void) {
    TMOD = 0x01;
    TH0  = 0xAA;
    TL0  = 0x10;
    TR0  = 1;      // 启动T0
    
    while(1) {
        if(TF0) {          // 查询溢出标志
            TF0 = 0;       // 软件清0溢出标志
            TH0 = 0xAA;    // 重装初值
            TL0 = 0x10;
            WAVE = ~WAVE;  // 翻转电平
        }
    }
}