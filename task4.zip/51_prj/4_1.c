#include <reg51.h>

// 共阳极数码管段码表（0~9，无小数点）
unsigned char code seg_table[] = {
    0xC0, // 0
    0xF9, // 1
    0xA4, // 2
    0xB0, // 3
    0x99, // 4
    0x92, // 5
    0x82, // 6
    0xF8, // 7
    0x80, // 8
    0x90  // 9
};

// 显示缓冲区，存放要显示的数字：2、0、2、6
unsigned char disp_buf[] = {2, 0, 2, 6};

// 延时函数（约1ms@11.0592MHz）
void delay_ms(unsigned int ms) {
    unsigned int i, j;
    for(i = ms; i > 0; i--)
        for(j = 110; j > 0; j--);
}

// 数码管动态扫描显示函数
void display(void) {
    unsigned char i;
    for(i = 0; i < 4; i++) {
        // 1. 关闭所有数码管，防止鬼影
        P2 |= 0x0F;
        
        // 2. 输出当前位的段码
        P1 = seg_table[disp_buf[i]];
        
        // 3. 选中当前位（低电平有效，P2.0~P2.3依次拉低）
        P2 &= ~(0x01 << i);
        
        // 4. 延时，保持当前位点亮
        delay_ms(1);
    }
}

void main(void) {
    while(1) {
        display(); // 循环执行动态扫描
    }
}