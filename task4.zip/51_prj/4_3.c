
#include <reg51.h>
// 共阳极数码管段码表 0~9
unsigned char code seg_table[] = {
    0xC0, // 0
    0xF9, // 1
    0xA4, // 2
    0xB0, // 3
    0x99, // 4
    0x92, // 5
    0x82, // 6
    0xF8, // 7
    0x80, // 8
    0x90  // 9
};

// 显示缓冲区：前两位固定00，后两位倒计时（初始24）
unsigned char disp_buf[] = {0, 0, 2, 4};

// 全局变量
unsigned char second = 24;    // 秒数初始值24
bit run_flag = 0;             // 运行标志：0=暂停，1=启动
unsigned int cnt = 0;          // 定时器计数变量

// 毫秒延时函数
void delay_ms(unsigned int ms)
{
    unsigned int i, j;
    for(i = ms; i > 0; i--)
        for(j = 110; j > 0; j--);
}

// 数码管动态显示
void display(void)
{
    unsigned char i;
    for(i = 0; i < 4; i++)
    {
        P2 |= 0x0F;                // 关闭所有位
        P1 = seg_table[disp_buf[i]]; // 输出段码
        P2 &= ~(1 << i);           // 选中当前位
        delay_ms(1);
    }
}

// 按键扫描：P3.0启动/暂停，P3.1复位24秒
void key_scan(void)
{
    // 启动/暂停键 P3.0
    if((P3 & 0x01) == 0)
    {
        delay_ms(20);
        if((P3 & 0x01) == 0)
        {
            run_flag = ~run_flag; // 标志位取反：启动↔暂停
            while((P3 & 0x01) == 0); // 等待松开
        }
    }

    // 复位24秒键 P3.1
    if((P3 & 0x02) == 0)
    {
        delay_ms(20);
        if((P3 & 0x02) == 0)
        {
            second = 24;        // 秒数恢复24
            run_flag = 0;       // 停止计时
            while((P3 & 0x02) == 0);
        }
    }
}

// 秒更新函数：把秒数→显示缓冲区
void sec_to_buf(void)
{
    disp_buf[2] = second / 10; // 十位
    disp_buf[3] = second % 10; // 个位
}

// 定时器0初始化（11.0592MHz，定时10ms）
void timer0_init(void)
{
    TMOD |= 0x01;  // 定时器0模式1
    TH0 = 0xDC;    // 高8位初值
    TL0 = 0x00;    // 低8位初值
    ET0 = 1;       // 使能定时器0中断
    TR0 = 1;       // 启动定时器0
    EA = 1;        // 开总中断
}

// 定时器0中断服务函数（每10ms进入一次）
void timer0() interrupt 1
{
    TH0 = 0xDC;    // 重装初值
    TL0 = 0x00;
    
    cnt++;         // 计数+1
    if(cnt >= 100) // 100×10ms=1秒
    {
        cnt = 0;   // 清零
        if(run_flag == 1 && second > 0) // 如果启动且秒数>0
        {
            second--; // 秒数-1
            sec_to_buf(); // 更新显示
        }
    }
}

void main(void)
{
    sec_to_buf();    // 初始化显示24
    timer0_init();   // 初始化定时器
    while(1)
    {
        display();   // 循环显示
        key_scan();  // 扫描按键
    }
}